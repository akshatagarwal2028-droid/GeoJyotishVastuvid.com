import { Phone, MapPin, Clock, MessageCircle } from "lucide-react";
import WhatsAppButton from "./WhatsAppButton";
import officeBanner from "@/assets/office-banner.jpeg";

const ConsultationCTA = () => {
  return (
    <section className="section-padding bg-muted relative overflow-hidden">
      <div className="container-custom">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <div>
            <span className="inline-block px-4 py-1.5 rounded-full text-sm font-medium bg-primary/10 text-primary mb-4">
              Book Your Consultation
            </span>
            <h2 className="section-title text-left">
              Ready to Transform Your Life?
            </h2>
            <div className="decorative-line mb-6" />
            
            <p className="text-muted-foreground mb-8 leading-relaxed text-lg">
              Take the first step towards a better future. Book your personal consultation 
              with Dr. Sheetal Chandra Jain today and discover the path to success, 
              happiness, and prosperity.
            </p>

            <div className="space-y-4 mb-8">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <Phone className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h4 className="font-semibold text-foreground">Call or WhatsApp</h4>
                  <a href="tel:+919827018510" className="text-primary font-medium text-lg">
                    +91 9827018510
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-gold/10 flex items-center justify-center flex-shrink-0">
                  <Clock className="w-6 h-6 text-gold" />
                </div>
                <div>
                  <h4 className="font-semibold text-foreground">Consultation Hours</h4>
                  <p className="text-muted-foreground">Monday to Saturday: 10:00 AM – 8:00 PM</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-secondary/10 flex items-center justify-center flex-shrink-0">
                  <MapPin className="w-6 h-6 text-secondary" />
                </div>
                <div>
                  <h4 className="font-semibold text-foreground">Visit Our Office</h4>
                  <p className="text-muted-foreground text-sm">
                    First Floor, Dr Sharma Ke Upar, Raghuvar Krishna Apartment,<br />
                    Old High Court Road, Mehna Wali Gali, Dal Bazaar, Lashkar,<br />
                    Gwalior, Madhya Pradesh – 474001
                  </p>
                </div>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <WhatsAppButton variant="hero" service="Booking Appointment" />
              <a
                href="tel:+919827018510"
                className="inline-flex items-center justify-center gap-2 btn-secondary"
              >
                <Phone className="w-5 h-5" />
                Call Now
              </a>
            </div>
          </div>

          {/* Image */}
          <div className="relative">
            <div className="rounded-2xl overflow-hidden shadow-elevated border-4 border-gold/20">
              <img
                src={officeBanner}
                alt="Geo Jyotish & Vastuvid Solution Office"
                className="w-full h-auto object-cover"
              />
            </div>
            
            {/* Floating card */}
            <div className="absolute -bottom-6 -left-6 bg-white rounded-xl shadow-elevated p-4 hidden md:block">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-[#25D366] flex items-center justify-center">
                  <MessageCircle className="w-6 h-6 text-white" fill="currentColor" />
                </div>
                <div>
                  <div className="font-semibold text-foreground">Quick Response</div>
                  <div className="text-sm text-muted-foreground">Usually within 1 hour</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ConsultationCTA;
