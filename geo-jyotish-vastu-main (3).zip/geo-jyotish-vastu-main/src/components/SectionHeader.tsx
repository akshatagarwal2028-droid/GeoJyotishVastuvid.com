interface SectionHeaderProps {
  badge?: string;
  title: string;
  subtitle?: string;
  center?: boolean;
  light?: boolean;
}

const SectionHeader = ({ badge, title, subtitle, center = true, light = false }: SectionHeaderProps) => {
  return (
    <div className={`mb-12 ${center ? "text-center" : ""}`}>
      {badge && (
        <span className={`inline-block px-4 py-1.5 rounded-full text-sm font-medium mb-4 ${
          light 
            ? "bg-white/10 text-white/90" 
            : "bg-primary/10 text-primary"
        }`}>
          {badge}
        </span>
      )}
      <h2 className={`section-title ${light ? "text-white" : ""}`}>{title}</h2>
      <div className={`decorative-line ${center ? "mx-auto" : ""} mt-4 mb-4`} />
      {subtitle && (
        <p className={`section-subtitle ${light ? "text-white/70" : ""}`}>{subtitle}</p>
      )}
    </div>
  );
};

export default SectionHeader;
