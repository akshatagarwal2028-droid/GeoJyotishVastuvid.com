import { Link } from "react-router-dom";
import { Award, BookOpen, Users, Star, ArrowRight, CheckCircle } from "lucide-react";
import drSheetalPortrait from "@/assets/dr-sheetal-portrait.jpeg";

const AboutPreview = () => {
  const achievements = [
    "15+ Years of Professional Experience",
    "Asia Book & India Book Record Holder",
    "Certified Vastuvid Expert",
    "10,000+ Satisfied Clients",
    "Motivational Speaker & Life Coach",
    "Reiki Master & Energy Healer",
  ];

  const stats = [
    { icon: Users, value: "10,000+", label: "Clients Served" },
    { icon: BookOpen, value: "15+", label: "Years Experience" },
    { icon: Award, value: "2", label: "Book Records" },
    { icon: Star, value: "100%", label: "Satisfaction" },
  ];

  return (
    <section className="section-padding bg-muted">
      <div className="container-custom">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Image Side */}
          <div className="relative">
            <div className="relative rounded-2xl overflow-hidden shadow-elevated">
              <img
                src={drSheetalPortrait}
                alt="Dr. Sheetal Chandra Jain"
                className="w-full h-auto object-cover"
              />
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-secondary via-secondary/80 to-transparent p-8">
                <h3 className="font-heading text-2xl font-bold text-white">
                  Dr. Sheetal Chandra Jain
                </h3>
                <p className="text-gold mt-1">Astrologer & Certified Vastuvid</p>
              </div>
            </div>

            {/* Stats Overlay */}
            <div className="absolute -bottom-6 -right-6 bg-white rounded-xl shadow-elevated p-6 hidden md:block">
              <div className="grid grid-cols-2 gap-4">
                {stats.map((stat, index) => (
                  <div key={index} className="text-center">
                    <stat.icon className="w-6 h-6 text-primary mx-auto mb-1" />
                    <div className="font-bold text-lg text-secondary">{stat.value}</div>
                    <div className="text-xs text-muted-foreground">{stat.label}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Content Side */}
          <div>
            <span className="inline-block px-4 py-1.5 rounded-full text-sm font-medium bg-primary/10 text-primary mb-4">
              About Our Founder
            </span>
            <h2 className="section-title text-left">
              Meet Dr. Sheetal Chandra Jain
            </h2>
            <div className="decorative-line mb-6" />
            
            <p className="text-muted-foreground mb-6 leading-relaxed">
              Dr. Sheetal Chandra Jain is a renowned Astrologer, Certified Vastuvid, and Reiki Healer 
              with over 15 years of experience in helping people transform their lives through ancient 
              Vedic wisdom. As the founder of Geo Jyotish & Vastuvid Solution and Research Centre, 
              he has guided thousands of individuals towards success, health, and prosperity.
            </p>
            
            <p className="text-muted-foreground mb-8 leading-relaxed">
              Recognized with Asia Book Record and India Book Record achievements, Dr. Jain combines 
              traditional astrological knowledge with modern scientific approaches to provide accurate 
              predictions and effective remedies.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-8">
              {achievements.map((achievement, index) => (
                <div key={index} className="flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-primary flex-shrink-0" />
                  <span className="text-sm text-foreground">{achievement}</span>
                </div>
              ))}
            </div>

            <Link
              to="/about"
              className="inline-flex items-center gap-2 btn-primary"
            >
              Learn More About Dr. Jain
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutPreview;
