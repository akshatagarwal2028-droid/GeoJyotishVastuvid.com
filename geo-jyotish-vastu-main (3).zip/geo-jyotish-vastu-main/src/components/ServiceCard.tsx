import { LucideIcon } from "lucide-react";
import WhatsAppButton from "./WhatsAppButton";

interface ServiceCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  iconBgClass?: string;
}

const ServiceCard = ({ icon: Icon, title, description, iconBgClass = "bg-primary/10" }: ServiceCardProps) => {
  return (
    <div className="group card-premium p-6 hover:border-primary/30 transition-all duration-300">
      <div className={`w-14 h-14 rounded-xl ${iconBgClass} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300`}>
        <Icon className="w-7 h-7 text-primary" />
      </div>
      <h3 className="font-heading font-semibold text-lg text-foreground mb-2">{title}</h3>
      <p className="text-muted-foreground text-sm mb-4 line-clamp-3">{description}</p>
      <WhatsAppButton service={title} />
    </div>
  );
};

export default ServiceCard;
