import { Link } from "react-router-dom";
import { MapPin, Phone, Mail, Clock, Star, Facebook, Instagram, Youtube } from "lucide-react";
import WhatsAppButton from "./WhatsAppButton";

const Footer = () => {
  const quickLinks = [
    { path: "/", label: "Home" },
    { path: "/about", label: "About Us" },
    { path: "/astrology-services", label: "Astrology Services" },
    { path: "/vastuvid-services", label: "Vastuvid Services" },
    { path: "/problems", label: "Problems We Solve" },
    { path: "/products", label: "Products & Remedies" },
    { path: "/contact", label: "Contact Us" },
  ];

  const services = [
    "Janam Kundli Analysis",
    "Marriage Matching",
    "Career Guidance",
    "Home Vastuvid",
    "Reiki Healing",
    "Gemstone Consultation",
  ];

  return (
    <footer className="bg-secondary text-secondary-foreground">
      {/* Main Footer */}
      <div className="max-w-7xl mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* About Column */}
          <div>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                <Star className="w-6 h-6 text-white" fill="currentColor" />
              </div>
              <div>
                <h3 className="font-heading font-bold text-lg">Geo Jyotish</h3>
                <p className="text-sm text-secondary-foreground/70">& Vastuvid Solution</p>
              </div>
            </div>
            <p className="text-secondary-foreground/80 text-sm leading-relaxed mb-6">
              Trusted astrology and Vastuvid consultancy providing authentic guidance for life's
              challenges through ancient Vedic wisdom and modern scientific approach.
            </p>
            <div className="flex gap-4">
              <a href="#" className="p-2 rounded-full bg-secondary-foreground/10 hover:bg-primary transition-colors">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="p-2 rounded-full bg-secondary-foreground/10 hover:bg-primary transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="p-2 rounded-full bg-secondary-foreground/10 hover:bg-primary transition-colors">
                <Youtube className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-heading font-semibold text-lg mb-6">Quick Links</h4>
            <ul className="space-y-3">
              {quickLinks.map((link) => (
                <li key={link.path}>
                  <Link
                    to={link.path}
                    className="text-secondary-foreground/80 hover:text-primary transition-colors text-sm"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="font-heading font-semibold text-lg mb-6">Our Services</h4>
            <ul className="space-y-3">
              {services.map((service) => (
                <li key={service}>
                  <span className="text-secondary-foreground/80 text-sm">{service}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="font-heading font-semibold text-lg mb-6">Contact Us</h4>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-primary mt-1 flex-shrink-0" />
                <span className="text-secondary-foreground/80 text-sm">
                  First Floor, Dr Sharma Ke Upar, Raghuvar Krishna Apartment, Old High Court Road,
                  Mehna Wali Gali, Dal Bazaar, Lashkar, Gwalior, MP – 474001
                </span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-primary flex-shrink-0" />
                <a href="tel:+919827018510" className="text-secondary-foreground/80 text-sm hover:text-primary transition-colors">
                  +91 9827018510
                </a>
              </li>
              <li className="flex items-center gap-3">
                <Clock className="w-5 h-5 text-primary flex-shrink-0" />
                <span className="text-secondary-foreground/80 text-sm">
                  Mon - Sat: 10:00 AM - 8:00 PM
                </span>
              </li>
            </ul>
            <div className="mt-6">
              <WhatsAppButton service="General Inquiry" />
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-secondary-foreground/10">
        <div className="max-w-7xl mx-auto px-4 py-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-secondary-foreground/60 text-sm text-center md:text-left">
            © 2024 Geo Jyotish & Vastuvid Solution and Research Centre. All rights reserved.
          </p>
          <p className="text-secondary-foreground/60 text-sm">
            Designed with ❤️ for your spiritual journey
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
