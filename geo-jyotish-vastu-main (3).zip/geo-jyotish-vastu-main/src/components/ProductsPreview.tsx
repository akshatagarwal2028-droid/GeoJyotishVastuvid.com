import { Link } from "react-router-dom";
import { Gem, CircleDot, Hexagon, FileText, ArrowRight } from "lucide-react";
import SectionHeader from "./SectionHeader";
import WhatsAppButton from "./WhatsAppButton";

const ProductsPreview = () => {
  const products = [
    {
      icon: Gem,
      title: "Certified Gemstones",
      description: "Authentic, lab-certified gemstones recommended based on your birth chart for maximum benefits.",
      items: ["Ruby", "Emerald", "Blue Sapphire", "Yellow Sapphire", "Diamond", "Pearl"],
    },
    {
      icon: CircleDot,
      title: "Rudraksha Collection",
      description: "Genuine Rudraksha beads from Nepal and Indonesia, energized with Vedic mantras.",
      items: ["1 Mukhi to 21 Mukhi", "Gauri Shankar", "Ganesh Rudraksha", "Trijuti"],
    },
    {
      icon: Hexagon,
      title: "Yantra Collection",
      description: "Sacred geometric instruments for specific purposes, energized with proper rituals.",
      items: ["Shree Yantra", "Kuber Yantra", "Vastu Yantra", "Protection Yantra"],
    },
    {
      icon: FileText,
      title: "Personalized Reports",
      description: "Detailed astrological reports and analysis for various life aspects.",
      items: ["Annual Prediction", "Marriage Report", "Career Analysis", "Health Report"],
    },
  ];

  return (
    <section className="section-padding bg-background">
      <div className="container-custom">
        <SectionHeader
          badge="Authentic Products"
          title="Products & Remedies"
          subtitle="Enhance your spiritual journey with our collection of certified gemstones, Rudraksha, Yantras, and personalized astrological remedies."
        />

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {products.map((product, index) => (
            <div key={index} className="card-premium p-6 text-center group">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary to-gold mx-auto mb-4 flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                <product.icon className="w-8 h-8 text-white" />
              </div>
              <h3 className="font-heading font-semibold text-lg text-foreground mb-2">{product.title}</h3>
              <p className="text-muted-foreground text-sm mb-4">{product.description}</p>
              <div className="flex flex-wrap gap-2 justify-center mb-4">
                {product.items.slice(0, 4).map((item, iIndex) => (
                  <span key={iIndex} className="px-2 py-1 bg-muted rounded-full text-xs text-muted-foreground">
                    {item}
                  </span>
                ))}
              </div>
              <WhatsAppButton service={product.title} />
            </div>
          ))}
        </div>

        <div className="text-center">
          <Link
            to="/products"
            className="inline-flex items-center gap-2 btn-secondary"
          >
            View All Products
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </div>
    </section>
  );
};

export default ProductsPreview;
