import { Star, Award, Users, Calendar } from "lucide-react";
import WhatsAppButton from "./WhatsAppButton";
import drSheetalPortrait from "@/assets/dr-sheetal-portrait.jpeg";

const Hero = () => {
  const stats = [
    { icon: Users, value: "10,000+", label: "Happy Clients" },
    { icon: Calendar, value: "15+", label: "Years Experience" },
    { icon: Award, value: "100%", label: "Accurate Predictions" },
  ];

  return (
    <section className="relative min-h-screen flex items-center pt-20 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-royal-dark via-royal to-royal-light" />
      
      {/* Decorative Elements */}
      <div className="absolute top-20 left-10 w-72 h-72 bg-primary/20 rounded-full blur-3xl" />
      <div className="absolute bottom-20 right-10 w-96 h-96 bg-gold/20 rounded-full blur-3xl" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] border border-gold/10 rounded-full" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] border border-gold/10 rounded-full" />
      
      {/* Zodiac decoration */}
      <div className="absolute top-32 right-20 hidden lg:block">
        <div className="w-20 h-20 border-2 border-gold/30 rounded-full flex items-center justify-center animate-float">
          <Star className="w-8 h-8 text-gold" fill="currentColor" />
        </div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 py-12 md:py-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <div className="text-center lg:text-left animate-slide-up">
            <div className="inline-flex items-center gap-2 bg-gold/20 text-gold px-4 py-2 rounded-full text-sm font-medium mb-6">
              <Star className="w-4 h-4" fill="currentColor" />
              Trusted Astrology & Vastuvid Consultant
            </div>
            
            <h1 className="font-heading text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight">
              Unlock Your <span className="text-primary">Destiny</span> with
              <br />
              <span className="text-gold">Vedic Wisdom</span>
            </h1>
            
            <p className="text-white/80 text-lg md:text-xl mb-8 max-w-xl mx-auto lg:mx-0">
              Transform your life with authentic astrology and Vastuvid guidance from 
              Dr. Sheetal Chandra Jain – your trusted consultant for success, health, 
              and prosperity.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start mb-12">
              <WhatsAppButton variant="hero" service="Personal Consultation" />
              <a
                href="tel:+919827018510"
                className="inline-flex items-center justify-center gap-2 bg-white/10 hover:bg-white/20 text-white font-semibold px-8 py-4 rounded-full border border-white/20 transition-all duration-300"
              >
                Call Now: +91 9827018510
              </a>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-6">
              {stats.map((stat, index) => (
                <div key={index} className="text-center">
                  <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-gold/20 mb-2">
                    <stat.icon className="w-6 h-6 text-gold" />
                  </div>
                  <div className="text-2xl md:text-3xl font-bold text-white">{stat.value}</div>
                  <div className="text-white/60 text-sm">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Image */}
          <div className="relative flex justify-center lg:justify-end animate-fade-in">
            <div className="relative">
              {/* Glow effect */}
              <div className="absolute inset-0 bg-gradient-to-t from-primary/30 to-gold/30 blur-3xl scale-110" />
              
              {/* Main image container */}
              <div className="relative w-[300px] md:w-[400px] lg:w-[450px] rounded-2xl overflow-hidden border-4 border-gold/30 shadow-2xl">
                <img
                  src={drSheetalPortrait}
                  alt="Dr. Sheetal Chandra Jain - Astrologer & Vastuvid Expert"
                  className="w-full h-auto object-cover"
                />
                
                {/* Overlay gradient */}
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent p-6">
                  <h3 className="font-heading text-2xl font-bold text-white">
                    Dr. Sheetal Chandra Jain
                  </h3>
                  <p className="text-gold text-sm mt-1">Astrologer & Certified Vastuvid</p>
                </div>
              </div>

              {/* Floating badge */}
              <div className="absolute -right-4 top-1/4 bg-white rounded-xl shadow-elevated p-4 animate-float">
                <div className="flex items-center gap-2">
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <Award className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <div className="font-semibold text-foreground text-sm">Certified</div>
                    <div className="text-muted-foreground text-xs">Vastuvid Expert</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Office Details Banner Footer */}
      <div className="absolute bottom-0 left-0 right-0 bg-royal-dark/95 backdrop-blur-sm border-t border-gold/20">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-8 text-center md:text-left">
            {/* Office Address */}
            <div className="space-y-1">
              <h4 className="text-gold font-heading font-semibold text-sm uppercase tracking-wider">Office Address</h4>
              <p className="text-white/90 text-xs leading-relaxed">
                First Floor, Dr Sharma Ke Upar,<br />
                Raghuvar Krishna Apartment,<br />
                Old High Court Road, Mehna Wali Gali,<br />
                Dal Bazaar, Lashkar,<br />
                <span className="font-semibold">Gwalior, MP – 474001</span>
              </p>
            </div>

            {/* Contact */}
            <div className="space-y-1">
              <h4 className="text-gold font-heading font-semibold text-sm uppercase tracking-wider">Consultation & WhatsApp</h4>
              <p className="text-white text-lg font-semibold">
                <a href="tel:+919827018510" className="hover:text-gold transition-colors">9827018510</a>
              </p>
            </div>

            {/* Office Manager */}
            <div className="space-y-1">
              <h4 className="text-gold font-heading font-semibold text-sm uppercase tracking-wider">Office Manager</h4>
              <p className="text-white/90 text-sm">
                <span className="font-semibold">Arti Agrawal</span>
              </p>
              <p className="text-white text-lg font-semibold">
                <a href="tel:+918817293517" className="hover:text-gold transition-colors">8817293517</a>
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
