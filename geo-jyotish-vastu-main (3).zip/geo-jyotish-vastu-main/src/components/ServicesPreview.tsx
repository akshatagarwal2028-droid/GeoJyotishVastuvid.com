import { Link } from "react-router-dom";
import { 
  Sun, Moon, Heart, Briefcase, GraduationCap, Plane,
  Home, Building2, Factory, Sparkles, ArrowRight
} from "lucide-react";
import SectionHeader from "./SectionHeader";
import ServiceCard from "./ServiceCard";

const ServicesPreview = () => {
  const astrologyServices = [
    { icon: Sun, title: "Janam Kundli Analysis", description: "Comprehensive birth chart reading revealing your life path, strengths, and karmic patterns." },
    { icon: Heart, title: "Marriage Matching", description: "Kundli matching for compatibility, ensuring harmonious and prosperous married life." },
    { icon: Briefcase, title: "Career Guidance", description: "Discover your ideal career path and timing for job changes and business ventures." },
    { icon: GraduationCap, title: "Education & Exams", description: "Astrological guidance for academic success and competitive examination timing." },
    { icon: Plane, title: "Foreign Travel", description: "Analysis of foreign settlement, travel, and overseas opportunities in your chart." },
    { icon: Moon, title: "Dasha–Mahadasha", description: "Detailed planetary period analysis for understanding life phases and timing events." },
  ];

  const vastuvudServices = [
    { icon: Home, title: "Home Vastuvid", description: "Transform your residence into a haven of positive energy and prosperity." },
    { icon: Building2, title: "Office & Commercial", description: "Optimize workplace energy for business growth and employee harmony." },
    { icon: Factory, title: "Factory & Industrial", description: "Industrial Vastuvid solutions for smooth operations and increased productivity." },
  ];

  const healingServices = [
    { icon: Sparkles, title: "Reiki Healing", description: "Universal life energy healing for physical, mental, and spiritual wellness." },
  ];

  return (
    <section className="section-padding bg-background">
      <div className="container-custom">
        <SectionHeader
          badge="Our Services"
          title="Expert Guidance for Life's Journey"
          subtitle="Discover our comprehensive range of astrology, Vastuvid, and healing services designed to bring positive transformation in your life."
        />

        {/* Astrology Services */}
        <div className="mb-16">
          <div className="flex items-center justify-between mb-8">
            <h3 className="font-heading text-2xl font-semibold text-secondary">Astrology Services</h3>
            <Link to="/astrology-services" className="text-primary font-medium flex items-center gap-1 hover:gap-2 transition-all">
              View All <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {astrologyServices.map((service, index) => (
              <ServiceCard key={index} {...service} />
            ))}
          </div>
        </div>

        {/* Vastuvid Services */}
        <div className="mb-16">
          <div className="flex items-center justify-between mb-8">
            <h3 className="font-heading text-2xl font-semibold text-secondary">Vastuvid Services</h3>
            <Link to="/vastuvid-services" className="text-primary font-medium flex items-center gap-1 hover:gap-2 transition-all">
              View All <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {vastuvudServices.map((service, index) => (
              <ServiceCard key={index} {...service} iconBgClass="bg-gold/10" />
            ))}
          </div>
        </div>

        {/* Healing Services */}
        <div>
          <div className="flex items-center justify-between mb-8">
            <h3 className="font-heading text-2xl font-semibold text-secondary">Healing Services</h3>
            <Link to="/astrology-services" className="text-primary font-medium flex items-center gap-1 hover:gap-2 transition-all">
              View All <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {healingServices.map((service, index) => (
              <ServiceCard key={index} {...service} iconBgClass="bg-secondary/10" />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ServicesPreview;
