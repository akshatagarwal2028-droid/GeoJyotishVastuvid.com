import { MessageCircle } from "lucide-react";

interface WhatsAppButtonProps {
  variant?: "floating" | "inline" | "hero";
  service?: string;
  className?: string;
}

const WhatsAppButton = ({ variant = "inline", service = "Service / Problem", className = "" }: WhatsAppButtonProps) => {
  const phoneNumber = "919827018510";
  const message = encodeURIComponent(
    `Hello, I want consultation from Geo Jyotish & Vastuvid Solution and Research Centre regarding ${service}.`
  );
  const whatsappUrl = `https://wa.me/${phoneNumber}?text=${message}`;

  if (variant === "floating") {
    return (
      <a
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 z-50 bg-[#25D366] hover:bg-[#20BD5A] text-white p-4 rounded-full shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-110 animate-pulse-glow"
        aria-label="Chat on WhatsApp"
      >
        <MessageCircle className="w-7 h-7" fill="currentColor" />
      </a>
    );
  }

  if (variant === "hero") {
    return (
      <a
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        className={`inline-flex items-center gap-3 bg-[#25D366] hover:bg-[#20BD5A] text-white font-semibold px-8 py-4 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 text-lg ${className}`}
      >
        <MessageCircle className="w-6 h-6" fill="currentColor" />
        Consult on WhatsApp
      </a>
    );
  }

  return (
    <a
      href={whatsappUrl}
      target="_blank"
      rel="noopener noreferrer"
      className={`inline-flex items-center gap-2 bg-[#25D366] hover:bg-[#20BD5A] text-white font-medium px-5 py-2.5 rounded-full shadow-md hover:shadow-lg transition-all duration-300 hover:scale-105 text-sm ${className}`}
    >
      <MessageCircle className="w-4 h-4" fill="currentColor" />
      WhatsApp
    </a>
  );
};

export default WhatsAppButton;
