import { Link } from "react-router-dom";
import { 
  Heart, Briefcase, Home, Scale, Brain, 
  TrendingDown, Shield, ArrowRight
} from "lucide-react";
import SectionHeader from "./SectionHeader";
import WhatsAppButton from "./WhatsAppButton";

const ProblemsPreview = () => {
  const problems = [
    { icon: Heart, title: "Marriage & Relationship", problems: ["Marriage Delay", "Love Marriage Issues", "Relationship Conflicts", "Divorce Problems"] },
    { icon: Briefcase, title: "Career & Business", problems: ["Career Confusion", "Job Instability", "Business Loss", "Promotion Delays"] },
    { icon: TrendingDown, title: "Financial Issues", problems: ["Financial Blockage", "Debt Problems", "Property Issues", "Investment Losses"] },
    { icon: Scale, title: "Legal & Family", problems: ["Court Cases", "Family Disputes", "Property Disputes", "Inheritance Issues"] },
    { icon: Brain, title: "Health & Mental", problems: ["Health Problems", "Mental Stress", "Fear & Anxiety", "Sleep Disorders"] },
    { icon: Shield, title: "Spiritual Issues", problems: ["Negative Energy", "Bad Luck Phases", "Repeated Failures", "Lack of Peace"] },
  ];

  return (
    <section className="section-padding bg-gradient-to-br from-secondary via-royal to-royal-light">
      <div className="container-custom">
        <SectionHeader
          badge="We Can Help"
          title="Problems We Solve"
          subtitle="No matter what challenges you're facing, our expert astrological guidance and Vastuvid solutions can help you overcome them."
          light
        />

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {problems.map((category, index) => (
            <div 
              key={index} 
              className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/10 hover:bg-white/15 transition-all duration-300"
            >
              <div className="w-12 h-12 rounded-xl bg-gold/20 flex items-center justify-center mb-4">
                <category.icon className="w-6 h-6 text-gold" />
              </div>
              <h3 className="font-heading font-semibold text-lg text-white mb-4">{category.title}</h3>
              <ul className="space-y-2 mb-4">
                {category.problems.map((problem, pIndex) => (
                  <li key={pIndex} className="text-white/70 text-sm flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-primary" />
                    {problem}
                  </li>
                ))}
              </ul>
              <WhatsAppButton service={category.title} />
            </div>
          ))}
        </div>

        <div className="text-center">
          <Link
            to="/problems"
            className="inline-flex items-center gap-2 bg-white text-secondary font-semibold px-8 py-4 rounded-full hover:bg-gold hover:text-white transition-all duration-300 shadow-lg"
          >
            View All Problems We Solve
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </div>
    </section>
  );
};

export default ProblemsPreview;
