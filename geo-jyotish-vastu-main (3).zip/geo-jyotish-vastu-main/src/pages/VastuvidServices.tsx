import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import SectionHeader from "@/components/SectionHeader";
import ServiceCard from "@/components/ServiceCard";
import WhatsAppButton from "@/components/WhatsAppButton";
import { 
  Home, Building2, Factory, Store, Warehouse, MapPin,
  AlertTriangle, Wrench, Layers
} from "lucide-react";

const VastuvidServices = () => {
  const vastuvidServices = [
    { icon: Home, title: "Home Vastuvid", description: "Transform your residence into a haven of positive energy, prosperity, and harmony with scientific Vastuvid principles." },
    { icon: Layers, title: "Flat / Apartment Vastuvid", description: "Specialized Vastuvid consultation for apartments and flats, optimizing limited space for maximum positive energy." },
    { icon: MapPin, title: "Plot & Land Vastuvid", description: "Analysis of land and plots for residential or commercial purposes, ensuring auspicious construction." },
    { icon: Building2, title: "Office & Commercial Vastuvid", description: "Optimize workplace energy for business growth, employee harmony, and increased productivity." },
    { icon: Store, title: "Shop & Showroom Vastuvid", description: "Retail space optimization for attracting customers, increasing sales, and business prosperity." },
    { icon: Factory, title: "Factory & Industrial Vastuvid", description: "Industrial Vastuvid solutions for smooth operations, worker safety, and increased productivity." },
    { icon: Warehouse, title: "Property Selection", description: "Expert guidance in selecting the right property based on Vastuvid principles for long-term benefits." },
    { icon: AlertTriangle, title: "Vastu Dosha Analysis", description: "Identify Vastuvid defects in existing properties and their effects on residents' life." },
    { icon: Wrench, title: "Vastu Correction (Without Demolition)", description: "Effective Vastuvid remedies and corrections without any structural changes or demolition." },
  ];

  const benefits = [
    "Enhanced prosperity and wealth",
    "Improved health and well-being",
    "Harmonious family relationships",
    "Career growth and success",
    "Mental peace and happiness",
    "Protection from negative energies",
    "Better sleep and rest",
    "Increased business profits",
  ];

  return (
    <div className="min-h-screen">
      <Navbar />
      
      {/* Hero Section */}
      <section className="pt-32 pb-16 bg-gradient-to-br from-royal-dark via-royal to-royal-light relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-10 w-72 h-72 bg-gold rounded-full blur-3xl" />
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-primary rounded-full blur-3xl" />
        </div>
        <div className="container-custom relative z-10">
          <SectionHeader
            badge="Vastuvid Services"
            title="Scientific Vastuvid Solutions"
            subtitle="Create positive energy environments for success, health, and prosperity"
            light
          />
          <div className="text-center">
            <WhatsAppButton variant="hero" service="Vastuvid Consultation" />
          </div>
        </div>
      </section>

      {/* About Vastuvid */}
      <section className="section-padding bg-background">
        <div className="container-custom">
          <div className="max-w-4xl mx-auto text-center mb-16">
            <span className="inline-block px-4 py-1.5 rounded-full text-sm font-medium bg-gold/10 text-gold mb-4">
              What is Vastuvid?
            </span>
            <h2 className="section-title">The Science of Architecture & Energy</h2>
            <div className="decorative-line mx-auto mb-6" />
            <p className="text-muted-foreground text-lg leading-relaxed mb-6">
              Vastuvid (also known as Vastu Shastra) is the ancient Indian science of architecture 
              and spatial arrangement. It combines the principles of design, layout, measurements, 
              ground preparation, space arrangement, and spatial geometry to create harmonious 
              living and working environments.
            </p>
            <p className="text-muted-foreground text-lg leading-relaxed">
              Dr. Sheetal Chandra Jain, as a Certified Vastuvid expert, provides scientific 
              Vastuvid analysis and practical solutions that bring positive changes without 
              requiring major structural modifications.
            </p>
          </div>

          {/* Benefits */}
          <div className="bg-muted rounded-2xl p-8 mb-16">
            <h3 className="font-heading text-2xl font-semibold text-center text-secondary mb-8">
              Benefits of Proper Vastuvid
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {benefits.map((benefit, index) => (
                <div key={index} className="flex items-center gap-2 bg-white rounded-lg p-4 shadow-soft">
                  <div className="w-2 h-2 rounded-full bg-primary flex-shrink-0" />
                  <span className="text-sm text-foreground">{benefit}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Vastuvid Services */}
      <section className="section-padding bg-muted">
        <div className="container-custom">
          <SectionHeader
            badge="Our Services"
            title="Comprehensive Vastuvid Services"
            subtitle="Expert Vastuvid consultation for all types of properties"
          />

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {vastuvidServices.map((service, index) => (
              <ServiceCard key={index} {...service} iconBgClass="bg-gold/10" />
            ))}
          </div>
        </div>
      </section>

      {/* Process */}
      <section className="section-padding bg-background">
        <div className="container-custom">
          <SectionHeader
            badge="Our Process"
            title="How We Work"
            subtitle="Simple and effective Vastuvid consultation process"
          />

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 max-w-5xl mx-auto">
            {[
              { step: "01", title: "Contact Us", description: "Reach out via WhatsApp or phone to schedule your consultation." },
              { step: "02", title: "Site Analysis", description: "We analyze your property plans or visit for on-site assessment." },
              { step: "03", title: "Detailed Report", description: "Receive comprehensive Vastuvid analysis with identified doshas." },
              { step: "04", title: "Remedies", description: "Get practical solutions and remedies without demolition." },
            ].map((item, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary to-gold mx-auto mb-4 flex items-center justify-center">
                  <span className="font-heading font-bold text-xl text-white">{item.step}</span>
                </div>
                <h3 className="font-heading font-semibold text-lg text-foreground mb-2">{item.title}</h3>
                <p className="text-muted-foreground text-sm">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-gradient-to-r from-gold to-primary">
        <div className="container-custom text-center">
          <h2 className="font-heading text-3xl md:text-4xl font-bold text-white mb-4">
            Transform Your Space Today
          </h2>
          <p className="text-white/80 text-lg mb-8 max-w-2xl mx-auto">
            Get expert Vastuvid consultation from Dr. Sheetal Chandra Jain and create 
            a harmonious environment for success and prosperity.
          </p>
          <WhatsAppButton variant="hero" service="Vastuvid Consultation Booking" />
        </div>
      </section>

      <Footer />
      <WhatsAppButton variant="floating" />
    </div>
  );
};

export default VastuvidServices;
