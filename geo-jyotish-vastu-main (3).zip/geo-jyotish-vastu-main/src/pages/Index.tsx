import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import ServicesPreview from "@/components/ServicesPreview";
import AboutPreview from "@/components/AboutPreview";
import ProblemsPreview from "@/components/ProblemsPreview";
import ProductsPreview from "@/components/ProductsPreview";
import ConsultationCTA from "@/components/ConsultationCTA";
import Footer from "@/components/Footer";
import WhatsAppButton from "@/components/WhatsAppButton";

const Index = () => {
  return (
    <div className="min-h-screen">
      <Navbar />
      <Hero />
      <ServicesPreview />
      <AboutPreview />
      <ProblemsPreview />
      <ProductsPreview />
      <ConsultationCTA />
      <Footer />
      <WhatsAppButton variant="floating" />
    </div>
  );
};

export default Index;
