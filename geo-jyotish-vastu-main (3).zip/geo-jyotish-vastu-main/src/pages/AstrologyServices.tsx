import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import SectionHeader from "@/components/SectionHeader";
import ServiceCard from "@/components/ServiceCard";
import WhatsAppButton from "@/components/WhatsAppButton";
import { 
  Sun, Moon, Heart, Briefcase, GraduationCap, Plane,
  Baby, Stethoscope, Scale, Pencil, Hash, Calendar,
  TrendingUp, Clock, Users, Building, Sparkles, 
  Brain, Zap, Shield, Smile, Compass
} from "lucide-react";

const AstrologyServices = () => {
  const astrologyServices = [
    { icon: Sun, title: "Janam Kundli Analysis", description: "Comprehensive birth chart reading revealing your life path, personality traits, strengths, weaknesses, and karmic patterns for a fulfilling life." },
    { icon: Moon, title: "Birth Chart Reading", description: "In-depth analysis of planetary positions at your birth time to understand your destiny and life purpose." },
    { icon: Clock, title: "Dasha–Mahadasha Analysis", description: "Detailed planetary period analysis to understand current and upcoming life phases, helping you plan important decisions." },
    { icon: Compass, title: "Gochar Analysis", description: "Transit analysis of planets to predict short-term effects and timing of events in your life." },
    { icon: Heart, title: "Marriage Matching", description: "Kundli matching for compatibility ensuring harmonious and prosperous married life with detailed Guna analysis." },
    { icon: Users, title: "Love Marriage Guidance", description: "Astrological support for love relationships, family approval, and successful love marriage solutions." },
    { icon: Heart, title: "Relationship Compatibility", description: "Analyze relationship dynamics and compatibility between partners for lasting harmony." },
    { icon: Briefcase, title: "Career Guidance", description: "Discover your ideal career path, best industries, and timing for job changes or starting business ventures." },
    { icon: TrendingUp, title: "Job Change & Promotion", description: "Optimal timing for job changes, salary negotiations, and career advancement opportunities." },
    { icon: Building, title: "Business Astrology", description: "Business name selection, partnership compatibility, and auspicious timing for business decisions." },
    { icon: TrendingUp, title: "Financial Growth", description: "Analysis of wealth potential, investment timing, and remedies for financial prosperity." },
    { icon: Plane, title: "Foreign Travel & Settlement", description: "Analysis of foreign opportunities, travel timing, and overseas settlement possibilities in your chart." },
    { icon: GraduationCap, title: "Education & Exams", description: "Guidance for academic success, course selection, and optimal timing for competitive examinations." },
    { icon: Baby, title: "Child Birth Prediction", description: "Analysis of progeny prospects, fertility timing, and remedies for childbirth-related concerns." },
    { icon: Stethoscope, title: "Health Astrology", description: "Identify health vulnerabilities, disease timing, and preventive measures through your birth chart." },
    { icon: Scale, title: "Court Case Astrology", description: "Legal matter analysis, case outcome prediction, and favorable timing for legal proceedings." },
    { icon: Pencil, title: "Name Correction", description: "Numerology-based name spelling corrections for enhanced luck and life improvements." },
    { icon: Hash, title: "Numerology Analysis", description: "Personal numerology reading revealing your life path number, destiny number, and lucky elements." },
    { icon: Hash, title: "Lucky Numbers & Colors", description: "Personalized lucky numbers, colors, and days based on your birth chart for daily guidance." },
    { icon: Calendar, title: "Muhurat Selection", description: "Auspicious timing for important events like marriage, house warming, business launch, and more." },
    { icon: Sun, title: "Annual Prediction", description: "Detailed year-ahead forecast covering all life areas with specific monthly predictions." },
  ];

  const healingServices = [
    { icon: Sparkles, title: "Reiki Healing", description: "Universal life energy healing technique for physical, mental, emotional, and spiritual wellness." },
    { icon: Zap, title: "Chakra Balancing", description: "Alignment and activation of seven chakras for overall health and spiritual development." },
    { icon: Shield, title: "Aura Cleansing", description: "Remove negative energies and blockages from your aura for enhanced well-being and protection." },
    { icon: Zap, title: "Energy Healing", description: "Holistic energy healing sessions for removing energy blocks and restoring natural flow." },
    { icon: Smile, title: "Stress Relief", description: "Specialized healing techniques for managing stress, anxiety, and achieving mental peace." },
    { icon: Brain, title: "Meditation Guidance", description: "Personalized meditation techniques for spiritual growth, mental clarity, and inner peace." },
  ];

  return (
    <div className="min-h-screen">
      <Navbar />
      
      {/* Hero Section */}
      <section className="pt-32 pb-16 bg-gradient-to-br from-royal-dark via-royal to-royal-light relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-10 w-72 h-72 bg-gold rounded-full blur-3xl" />
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-primary rounded-full blur-3xl" />
        </div>
        <div className="container-custom relative z-10">
          <SectionHeader
            badge="Astrology Services"
            title="Vedic Astrology & Healing Services"
            subtitle="Unlock the secrets of your destiny with our comprehensive astrology and healing services"
            light
          />
          <div className="text-center">
            <WhatsAppButton variant="hero" service="Astrology Consultation" />
          </div>
        </div>
      </section>

      {/* Astrology Services */}
      <section className="section-padding bg-background">
        <div className="container-custom">
          <SectionHeader
            badge="Jyotish Services"
            title="Astrology Services"
            subtitle="Comprehensive Vedic astrology services to guide you through life's journey"
          />

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {astrologyServices.map((service, index) => (
              <ServiceCard key={index} {...service} />
            ))}
          </div>
        </div>
      </section>

      {/* Healing Services */}
      <section className="section-padding bg-muted">
        <div className="container-custom">
          <SectionHeader
            badge="Healing Services"
            title="Energy Healing & Spiritual Wellness"
            subtitle="Holistic healing techniques for physical, mental, and spiritual well-being"
          />

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {healingServices.map((service, index) => (
              <ServiceCard key={index} {...service} iconBgClass="bg-secondary/10" />
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-gradient-to-r from-primary to-gold">
        <div className="container-custom text-center">
          <h2 className="font-heading text-3xl md:text-4xl font-bold text-white mb-4">
            Ready to Discover Your Destiny?
          </h2>
          <p className="text-white/80 text-lg mb-8 max-w-2xl mx-auto">
            Book your consultation with Dr. Sheetal Chandra Jain today and take the first step towards a transformed life.
          </p>
          <WhatsAppButton variant="hero" service="Astrology Consultation Booking" />
        </div>
      </section>

      <Footer />
      <WhatsAppButton variant="floating" />
    </div>
  );
};

export default AstrologyServices;
