import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import SectionHeader from "@/components/SectionHeader";
import WhatsAppButton from "@/components/WhatsAppButton";
import { 
  Gem, CircleDot, Hexagon, FileText, Shield, Star,
  CheckCircle, Award
} from "lucide-react";

const Products = () => {
  const gemstones = [
    { name: "Ruby (Manik)", planet: "Sun", benefits: "Leadership, confidence, success" },
    { name: "Pearl (Moti)", planet: "Moon", benefits: "Emotional balance, peace of mind" },
    { name: "Red Coral (Moonga)", planet: "Mars", benefits: "Courage, energy, property gains" },
    { name: "Emerald (Panna)", planet: "Mercury", benefits: "Intelligence, business success" },
    { name: "Yellow Sapphire (Pukhraj)", planet: "Jupiter", benefits: "Wisdom, wealth, marriage" },
    { name: "Diamond (Heera)", planet: "Venus", benefits: "Luxury, relationships, art" },
    { name: "Blue Sapphire (Neelam)", planet: "Saturn", benefits: "Career, discipline, obstacles removal" },
    { name: "Hessonite (Gomed)", planet: "Rahu", benefits: "Protection, clarity, success" },
    { name: "Cat's Eye (Lahsuniya)", planet: "Ketu", benefits: "Spiritual growth, protection" },
  ];

  const rudrakshas = [
    { name: "1 Mukhi Rudraksha", deity: "Shiva", benefits: "Spiritual enlightenment, moksha" },
    { name: "2 Mukhi Rudraksha", deity: "Ardhanarishwar", benefits: "Unity, relationships" },
    { name: "3 Mukhi Rudraksha", deity: "Agni", benefits: "Self-confidence, energy" },
    { name: "4 Mukhi Rudraksha", deity: "Brahma", benefits: "Knowledge, creativity" },
    { name: "5 Mukhi Rudraksha", deity: "Kalagni Rudra", benefits: "Peace, health" },
    { name: "6 Mukhi Rudraksha", deity: "Kartikeya", benefits: "Wisdom, willpower" },
    { name: "7 Mukhi Rudraksha", deity: "Mahalakshmi", benefits: "Wealth, prosperity" },
    { name: "Gauri Shankar", deity: "Shiva-Parvati", benefits: "Marriage, harmony" },
    { name: "Ganesh Rudraksha", deity: "Ganesha", benefits: "Success, obstacle removal" },
  ];

  const yantras = [
    { name: "Shree Yantra", purpose: "Wealth & prosperity", description: "The king of all Yantras for attracting abundance and Lakshmi's blessings." },
    { name: "Kuber Yantra", purpose: "Financial gains", description: "Attracts wealth, business success, and removes financial obstacles." },
    { name: "Vastu Yantra", purpose: "Vastu correction", description: "Neutralizes Vastu defects and brings positive energy to spaces." },
    { name: "Navgraha Yantra", purpose: "Planetary harmony", description: "Balances all nine planets for overall life improvement." },
    { name: "Mahamrityunjaya Yantra", purpose: "Health & protection", description: "Powerful protection from diseases and untimely death." },
    { name: "Baglamukhi Yantra", purpose: "Victory over enemies", description: "Protection from enemies, legal success, and obstacle removal." },
  ];

  const reports = [
    { name: "Complete Kundli Report", pages: "50+", description: "Comprehensive birth chart analysis with predictions" },
    { name: "Annual Prediction Report", pages: "25+", description: "Detailed year-ahead forecast for all life areas" },
    { name: "Marriage Compatibility", pages: "15+", description: "Guna matching and compatibility analysis" },
    { name: "Career Analysis Report", pages: "20+", description: "Career path, timing, and success strategies" },
    { name: "Health Analysis Report", pages: "15+", description: "Health vulnerabilities and preventive measures" },
    { name: "Child Birth Report", pages: "15+", description: "Progeny analysis and fertility guidance" },
  ];

  return (
    <div className="min-h-screen">
      <Navbar />
      
      {/* Hero Section */}
      <section className="pt-32 pb-16 bg-gradient-to-br from-royal-dark via-royal to-royal-light relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-10 w-72 h-72 bg-gold rounded-full blur-3xl" />
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-primary rounded-full blur-3xl" />
        </div>
        <div className="container-custom relative z-10">
          <SectionHeader
            badge="Authentic Products"
            title="Products & Remedies"
            subtitle="Certified gemstones, Rudraksha, Yantras, and personalized remedies for positive transformation"
            light
          />
          <div className="text-center">
            <WhatsAppButton variant="hero" service="Product Inquiry" />
          </div>
        </div>
      </section>

      {/* Quality Assurance */}
      <section className="py-12 bg-primary/5">
        <div className="container-custom">
          <div className="flex flex-wrap justify-center gap-8">
            {[
              { icon: CheckCircle, text: "100% Authentic Products" },
              { icon: Award, text: "Lab Certified Gemstones" },
              { icon: Star, text: "Energized with Vedic Mantras" },
              { icon: Shield, text: "Quality Guaranteed" },
            ].map((item, index) => (
              <div key={index} className="flex items-center gap-2">
                <item.icon className="w-5 h-5 text-primary" />
                <span className="font-medium text-foreground">{item.text}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Gemstones */}
      <section className="section-padding bg-background">
        <div className="container-custom">
          <div className="flex items-center gap-4 mb-8">
            <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-primary to-gold flex items-center justify-center">
              <Gem className="w-7 h-7 text-white" />
            </div>
            <div>
              <h2 className="font-heading text-2xl font-bold text-secondary">Certified Gemstones</h2>
              <p className="text-muted-foreground">Lab-certified precious and semi-precious stones</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {gemstones.map((gem, index) => (
              <div key={index} className="card-premium p-4 flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <Gem className="w-6 h-6 text-primary" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-foreground">{gem.name}</h3>
                  <p className="text-sm text-muted-foreground">Planet: {gem.planet}</p>
                  <p className="text-xs text-primary">{gem.benefits}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center mt-8">
            <WhatsAppButton service="Gemstone Consultation" />
          </div>
        </div>
      </section>

      {/* Rudraksha */}
      <section className="section-padding bg-muted">
        <div className="container-custom">
          <div className="flex items-center gap-4 mb-8">
            <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-secondary to-royal-light flex items-center justify-center">
              <CircleDot className="w-7 h-7 text-white" />
            </div>
            <div>
              <h2 className="font-heading text-2xl font-bold text-secondary">Rudraksha Collection</h2>
              <p className="text-muted-foreground">Genuine Rudraksha from Nepal and Indonesia</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {rudrakshas.map((rudraksha, index) => (
              <div key={index} className="card-premium p-4 flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-secondary/10 flex items-center justify-center flex-shrink-0">
                  <CircleDot className="w-6 h-6 text-secondary" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-foreground">{rudraksha.name}</h3>
                  <p className="text-sm text-muted-foreground">Deity: {rudraksha.deity}</p>
                  <p className="text-xs text-primary">{rudraksha.benefits}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center mt-8">
            <WhatsAppButton service="Rudraksha Inquiry" />
          </div>
        </div>
      </section>

      {/* Yantras */}
      <section className="section-padding bg-background">
        <div className="container-custom">
          <div className="flex items-center gap-4 mb-8">
            <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-gold to-primary flex items-center justify-center">
              <Hexagon className="w-7 h-7 text-white" />
            </div>
            <div>
              <h2 className="font-heading text-2xl font-bold text-secondary">Yantra Collection</h2>
              <p className="text-muted-foreground">Sacred geometric instruments energized with Vedic rituals</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {yantras.map((yantra, index) => (
              <div key={index} className="card-premium p-6">
                <div className="w-12 h-12 rounded-xl bg-gold/10 flex items-center justify-center mb-4">
                  <Hexagon className="w-6 h-6 text-gold" />
                </div>
                <h3 className="font-heading font-semibold text-lg text-foreground mb-1">{yantra.name}</h3>
                <p className="text-sm text-primary mb-2">{yantra.purpose}</p>
                <p className="text-muted-foreground text-sm mb-4">{yantra.description}</p>
                <WhatsAppButton service={yantra.name} />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Reports */}
      <section className="section-padding bg-muted">
        <div className="container-custom">
          <div className="flex items-center gap-4 mb-8">
            <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
              <FileText className="w-7 h-7 text-white" />
            </div>
            <div>
              <h2 className="font-heading text-2xl font-bold text-secondary">Personalized Reports</h2>
              <p className="text-muted-foreground">Detailed astrological analysis and predictions</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {reports.map((report, index) => (
              <div key={index} className="card-premium p-6">
                <div className="flex items-center justify-between mb-4">
                  <FileText className="w-8 h-8 text-primary" />
                  <span className="px-3 py-1 bg-primary/10 text-primary text-sm rounded-full">{report.pages} pages</span>
                </div>
                <h3 className="font-heading font-semibold text-lg text-foreground mb-2">{report.name}</h3>
                <p className="text-muted-foreground text-sm mb-4">{report.description}</p>
                <WhatsAppButton service={report.name} />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-gradient-to-r from-secondary to-royal-light">
        <div className="container-custom text-center">
          <h2 className="font-heading text-3xl md:text-4xl font-bold text-white mb-4">
            Need Personalized Recommendations?
          </h2>
          <p className="text-white/80 text-lg mb-8 max-w-2xl mx-auto">
            Every individual is unique. Get personalized product recommendations based on your 
            birth chart from Dr. Sheetal Chandra Jain.
          </p>
          <WhatsAppButton variant="hero" service="Personalized Product Recommendation" />
        </div>
      </section>

      <Footer />
      <WhatsAppButton variant="floating" />
    </div>
  );
};

export default Products;
