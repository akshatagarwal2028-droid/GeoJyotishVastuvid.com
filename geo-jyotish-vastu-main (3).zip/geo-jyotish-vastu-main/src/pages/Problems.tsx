import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import SectionHeader from "@/components/SectionHeader";
import WhatsAppButton from "@/components/WhatsAppButton";
import { 
  Heart, HeartCrack, Users, Home, Briefcase, TrendingDown, 
  Scale, Stethoscope, Brain, Shield, AlertTriangle, XCircle,
  Clock, Frown, Moon, Repeat, Skull, Cloud
} from "lucide-react";

const Problems = () => {
  const problems = [
    { icon: Clock, title: "Marriage Delay", description: "Delayed marriage despite repeated efforts? Our astrological analysis identifies blocks and provides effective remedies for timely marriage." },
    { icon: Heart, title: "Love Marriage Issues", description: "Facing family opposition or relationship hurdles in love marriage? Get astrological solutions for successful love marriage." },
    { icon: HeartCrack, title: "Relationship Conflicts", description: "Constant misunderstandings and conflicts with your partner? Resolve relationship issues through Kundli analysis and remedies." },
    { icon: XCircle, title: "Divorce Problems", description: "Marriage on the verge of collapse? Our astrological guidance can help save your relationship and find peaceful solutions." },
    { icon: Users, title: "Family Disputes", description: "Ongoing conflicts within the family affecting peace? Get Vastuvid and astrological remedies for family harmony." },
    { icon: Briefcase, title: "Career Confusion", description: "Unsure about your career path or facing frequent job changes? Discover your ideal career through birth chart analysis." },
    { icon: AlertTriangle, title: "Job Instability", description: "Facing sudden job loss or workplace issues? Our analysis reveals planetary causes and provides stability solutions." },
    { icon: TrendingDown, title: "Business Loss", description: "Continuous losses despite hard work? Business astrology and Vastuvid can identify and remove success blocks." },
    { icon: TrendingDown, title: "Financial Blockage", description: "Money comes but doesn't stay? Remove financial blocks through astrological remedies and attract abundance." },
    { icon: TrendingDown, title: "Debt Problems", description: "Trapped in the cycle of debt? Get astrological remedies to clear debts and achieve financial freedom." },
    { icon: Home, title: "Property Issues", description: "Disputes over property or unable to sell/buy property? Astrological and Vastuvid solutions for property matters." },
    { icon: Scale, title: "Court Cases", description: "Long-pending legal matters draining your resources? Court case astrology for favorable outcomes and timing." },
    { icon: Stethoscope, title: "Health Problems", description: "Chronic health issues not improving with treatment? Identify karmic health patterns and get healing remedies." },
    { icon: Brain, title: "Mental Stress", description: "Overwhelmed by anxiety and stress? Healing therapies and astrological remedies for mental peace and clarity." },
    { icon: Shield, title: "Negative Energy", description: "Feeling presence of negative energy at home or workplace? Aura cleansing and protection remedies available." },
    { icon: Frown, title: "Fear & Anxiety", description: "Unexplained fears and anxiety affecting daily life? Get root cause analysis and healing solutions." },
    { icon: Repeat, title: "Repeated Failures", description: "Same problems occurring again and again? Break the cycle of repeated failures with karmic remedies." },
    { icon: Skull, title: "Bad Luck Phases", description: "Everything going wrong despite best efforts? Identify and remedy the Dasha effects causing bad luck." },
    { icon: Cloud, title: "Lack of Peace", description: "No peace of mind despite having everything? Find inner peace through spiritual guidance and meditation." },
  ];

  return (
    <div className="min-h-screen">
      <Navbar />
      
      {/* Hero Section */}
      <section className="pt-32 pb-16 bg-gradient-to-br from-royal-dark via-royal to-royal-light relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-10 w-72 h-72 bg-gold rounded-full blur-3xl" />
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-primary rounded-full blur-3xl" />
        </div>
        <div className="container-custom relative z-10">
          <SectionHeader
            badge="We Can Help"
            title="Problems We Solve"
            subtitle="No matter what challenges you're facing, our expert guidance can help you overcome them"
            light
          />
          <div className="text-center">
            <WhatsAppButton variant="hero" service="Problem Discussion" />
          </div>
        </div>
      </section>

      {/* Introduction */}
      <section className="py-16 bg-background">
        <div className="container-custom">
          <div className="max-w-4xl mx-auto text-center">
            <p className="text-muted-foreground text-lg leading-relaxed mb-6">
              Life can present many challenges - from personal relationships to career setbacks, 
              financial troubles to health issues. At Geo Jyotish & Vastuvid Solution and Research Centre, 
              we understand that these problems often have deeper roots in planetary positions, 
              karmic patterns, or Vastuvid imbalances.
            </p>
            <p className="text-muted-foreground text-lg leading-relaxed">
              Dr. Sheetal Chandra Jain uses a combination of Vedic astrology, Vastuvid science, 
              and healing techniques to identify the root causes of your problems and provide 
              effective, practical solutions.
            </p>
          </div>
        </div>
      </section>

      {/* Problems Grid */}
      <section className="section-padding bg-muted">
        <div className="container-custom">
          <SectionHeader
            badge="Find Your Solution"
            title="Common Problems We Address"
            subtitle="Click on any problem to discuss your specific situation with Dr. Sheetal Chandra Jain"
          />

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {problems.map((problem, index) => (
              <div key={index} className="card-premium p-6 hover:border-primary/30 transition-all duration-300 group">
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                  <problem.icon className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-heading font-semibold text-lg text-foreground mb-2">{problem.title}</h3>
                <p className="text-muted-foreground text-sm mb-4">{problem.description}</p>
                <WhatsAppButton service={problem.title} />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-gradient-to-r from-primary to-gold">
        <div className="container-custom text-center">
          <h2 className="font-heading text-3xl md:text-4xl font-bold text-white mb-4">
            Don't Suffer in Silence
          </h2>
          <p className="text-white/80 text-lg mb-8 max-w-2xl mx-auto">
            Every problem has a solution. Take the first step towards a better life by 
            sharing your concerns with Dr. Sheetal Chandra Jain today.
          </p>
          <WhatsAppButton variant="hero" service="Personal Problem Discussion" />
        </div>
      </section>

      <Footer />
      <WhatsAppButton variant="floating" />
    </div>
  );
};

export default Problems;
