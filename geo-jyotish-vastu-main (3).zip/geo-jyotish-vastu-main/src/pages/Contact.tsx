import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import SectionHeader from "@/components/SectionHeader";
import WhatsAppButton from "@/components/WhatsAppButton";
import { MapPin, Phone, Clock, MessageCircle, Mail } from "lucide-react";
import officeBanner from "@/assets/office-banner.jpeg";

const Contact = () => {
  return (
    <div className="min-h-screen">
      <Navbar />
      
      {/* Hero Section */}
      <section className="pt-32 pb-16 bg-gradient-to-br from-royal-dark via-royal to-royal-light relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-10 w-72 h-72 bg-gold rounded-full blur-3xl" />
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-primary rounded-full blur-3xl" />
        </div>
        <div className="container-custom relative z-10">
          <SectionHeader
            badge="Get in Touch"
            title="Contact Us"
            subtitle="We're here to help you on your spiritual journey"
            light
          />
          <div className="text-center">
            <WhatsAppButton variant="hero" service="General Inquiry" />
          </div>
        </div>
      </section>

      {/* Contact Info */}
      <section className="section-padding bg-background">
        <div className="container-custom">
          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Details */}
            <div>
              <h2 className="section-title text-left mb-8">Get in Touch</h2>
              
              <div className="space-y-6 mb-8">
                <div className="card-premium p-6 flex items-start gap-4">
                  <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <Phone className="w-7 h-7 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-heading font-semibold text-lg text-foreground mb-1">Call or WhatsApp</h3>
                    <a href="tel:+919827018510" className="text-xl font-semibold text-primary hover:underline">
                      +91 9827018510
                    </a>
                    <p className="text-muted-foreground text-sm mt-1">Available for calls and WhatsApp</p>
                  </div>
                </div>

                <div className="card-premium p-6 flex items-start gap-4">
                  <div className="w-14 h-14 rounded-xl bg-gold/10 flex items-center justify-center flex-shrink-0">
                    <Clock className="w-7 h-7 text-gold" />
                  </div>
                  <div>
                    <h3 className="font-heading font-semibold text-lg text-foreground mb-1">Consultation Hours</h3>
                    <p className="text-foreground font-medium">Monday to Saturday</p>
                    <p className="text-muted-foreground">10:00 AM – 8:00 PM</p>
                    <p className="text-muted-foreground text-sm mt-1">Sunday: By Appointment Only</p>
                  </div>
                </div>

                <div className="card-premium p-6 flex items-start gap-4">
                  <div className="w-14 h-14 rounded-xl bg-secondary/10 flex items-center justify-center flex-shrink-0">
                    <MapPin className="w-7 h-7 text-secondary" />
                  </div>
                  <div>
                    <h3 className="font-heading font-semibold text-lg text-foreground mb-1">Office Address</h3>
                    <p className="text-foreground">
                      First Floor, Dr Sharma Ke Upar,<br />
                      Raghuvar Krishna Apartment,<br />
                      Old High Court Road,<br />
                      Mehna Wali Gali,<br />
                      Dal Bazaar, Lashkar,<br />
                      <strong>Gwalior, Madhya Pradesh – 474001</strong>
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <WhatsAppButton variant="hero" service="Office Visit Inquiry" />
                <a
                  href="tel:+919827018510"
                  className="inline-flex items-center justify-center gap-2 btn-secondary"
                >
                  <Phone className="w-5 h-5" />
                  Call Now
                </a>
              </div>
            </div>

            {/* Office Image & Map */}
            <div className="space-y-6">
              <div className="rounded-2xl overflow-hidden shadow-elevated border-4 border-gold/20">
                <img
                  src={officeBanner}
                  alt="Geo Jyotish & Vastuvid Solution Office - Gwalior"
                  className="w-full h-auto object-cover"
                />
              </div>

              {/* Google Maps Embed */}
              <div className="rounded-2xl overflow-hidden shadow-elevated h-[300px]">
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3579.7987654321234!2d78.1688!3d26.2156!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjbCsDEyJzU2LjIiTiA3OMKwMTAnMDcuNyJF!5e0!3m2!1sen!2sin!4v1234567890"
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  title="Geo Jyotish & Vastuvid Solution Office Location"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Quick Contact CTA */}
      <section className="py-16 bg-gradient-to-r from-primary to-gold">
        <div className="container-custom">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <h2 className="font-heading text-3xl md:text-4xl font-bold text-white mb-4">
                Prefer WhatsApp?
              </h2>
              <p className="text-white/80 text-lg mb-6">
                Send us a message on WhatsApp for quick responses. We usually reply within 1 hour 
                during consultation hours.
              </p>
              <WhatsAppButton variant="hero" service="Quick Inquiry" />
            </div>
            <div className="text-center">
              <div className="inline-flex items-center justify-center w-32 h-32 rounded-full bg-white/20">
                <MessageCircle className="w-16 h-16 text-white" fill="currentColor" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Quick Links */}
      <section className="section-padding bg-muted">
        <div className="container-custom">
          <SectionHeader
            badge="Quick Consultation"
            title="What Do You Need Help With?"
            subtitle="Select your concern and connect with us directly"
          />

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              "Marriage & Relationships",
              "Career & Business",
              "Health Issues",
              "Financial Problems",
              "Home Vastuvid",
              "Office Vastuvid",
              "Gemstone Advice",
              "General Consultation",
            ].map((service, index) => (
              <div key={index} className="card-premium p-4 text-center hover:border-primary/30 transition-colors">
                <h3 className="font-medium text-foreground mb-3">{service}</h3>
                <WhatsAppButton service={service} />
              </div>
            ))}
          </div>
        </div>
      </section>

      <Footer />
      <WhatsAppButton variant="floating" />
    </div>
  );
};

export default Contact;
