import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import SectionHeader from "@/components/SectionHeader";
import WhatsAppButton from "@/components/WhatsAppButton";
import { Award, BookOpen, Users, Star, CheckCircle, Target, Eye, Heart } from "lucide-react";
import drSheetalPortrait from "@/assets/dr-sheetal-portrait.jpeg";
import officeBanner from "@/assets/office-banner.jpeg";

const About = () => {
  const achievements = [
    "15+ Years of Professional Experience",
    "Asia Book Record Holder",
    "India Book Record Holder",
    "Certified Vastuvid Expert",
    "10,000+ Satisfied Clients",
    "Motivational Speaker & Life Coach",
    "Reiki Master & Energy Healer",
    "Numerology Expert",
  ];

  const values = [
    { icon: Target, title: "Our Mission", description: "To provide authentic astrological guidance and Vastuvid solutions that bring positive transformation in people's lives, helping them achieve success, health, and prosperity." },
    { icon: Eye, title: "Our Vision", description: "To be the most trusted astrology and Vastuvid consultancy, known for accurate predictions, effective remedies, and genuine care for our clients' well-being." },
    { icon: Heart, title: "Our Values", description: "Authenticity, integrity, compassion, and commitment to client satisfaction guide everything we do. We believe in the transformative power of Vedic wisdom." },
  ];

  return (
    <div className="min-h-screen">
      <Navbar />
      
      {/* Hero Section */}
      <section className="pt-32 pb-16 bg-gradient-to-br from-royal-dark via-royal to-royal-light relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-10 w-72 h-72 bg-gold rounded-full blur-3xl" />
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-primary rounded-full blur-3xl" />
        </div>
        <div className="container-custom relative z-10">
          <SectionHeader
            badge="About Us"
            title="Geo Jyotish & Vastuvid Solution and Research Centre"
            subtitle="Your trusted destination for authentic astrology, Vastuvid, and healing services in Gwalior"
            light
          />
        </div>
      </section>

      {/* About Dr. Sheetal */}
      <section className="section-padding bg-background">
        <div className="container-custom">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="relative">
              <div className="rounded-2xl overflow-hidden shadow-elevated border-4 border-gold/20">
                <img
                  src={drSheetalPortrait}
                  alt="Dr. Sheetal Chandra Jain"
                  className="w-full h-auto object-cover"
                />
              </div>
              
              {/* Stats */}
              <div className="absolute -bottom-6 -right-6 bg-white rounded-xl shadow-elevated p-6 hidden md:block">
                <div className="grid grid-cols-2 gap-6">
                  <div className="text-center">
                    <Users className="w-8 h-8 text-primary mx-auto mb-2" />
                    <div className="font-bold text-2xl text-secondary">10,000+</div>
                    <div className="text-sm text-muted-foreground">Clients</div>
                  </div>
                  <div className="text-center">
                    <BookOpen className="w-8 h-8 text-gold mx-auto mb-2" />
                    <div className="font-bold text-2xl text-secondary">15+</div>
                    <div className="text-sm text-muted-foreground">Years</div>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <span className="inline-block px-4 py-1.5 rounded-full text-sm font-medium bg-primary/10 text-primary mb-4">
                Meet Our Founder
              </span>
              <h2 className="section-title text-left">Dr. Sheetal Chandra Jain</h2>
              <div className="decorative-line mb-6" />
              
              <p className="text-muted-foreground mb-6 leading-relaxed">
                Dr. Sheetal Chandra Jain is a highly respected Astrologer, Certified Vastuvid, 
                Reiki Healer, Motivational Speaker, and Life Coach based in Gwalior, Madhya Pradesh. 
                With over 15 years of dedicated practice, he has established himself as one of the 
                most trusted names in the field of Vedic astrology and Vastuvid.
              </p>
              
              <p className="text-muted-foreground mb-6 leading-relaxed">
                Recognized with prestigious Asia Book Record and India Book Record achievements, 
                Dr. Jain combines traditional Vedic knowledge with modern scientific approaches 
                to provide accurate predictions and effective remedies. His compassionate approach 
                and genuine care for clients have earned him a loyal following of over 10,000 
                satisfied clients.
              </p>

              <p className="text-muted-foreground mb-8 leading-relaxed">
                As the founder of Geo Jyotish & Vastuvid Solution and Research Centre, 
                Dr. Jain continues his mission to help people overcome life's challenges 
                and achieve their full potential through the wisdom of ancient Indian sciences.
              </p>

              <div className="grid grid-cols-2 gap-3 mb-8">
                {achievements.map((achievement, index) => (
                  <div key={index} className="flex items-center gap-2">
                    <CheckCircle className="w-5 h-5 text-primary flex-shrink-0" />
                    <span className="text-sm text-foreground">{achievement}</span>
                  </div>
                ))}
              </div>

              <WhatsAppButton variant="hero" service="Personal Consultation with Dr. Jain" />
            </div>
          </div>
        </div>
      </section>

      {/* Office Banner */}
      <section className="py-16">
        <div className="container-custom">
          <div className="rounded-2xl overflow-hidden shadow-elevated">
            <img
              src={officeBanner}
              alt="Geo Jyotish & Vastuvid Solution Office - Gwalior"
              className="w-full h-auto object-cover"
            />
          </div>
        </div>
      </section>

      {/* Mission, Vision, Values */}
      <section className="section-padding bg-muted">
        <div className="container-custom">
          <SectionHeader
            badge="What We Stand For"
            title="Our Mission, Vision & Values"
            subtitle="Guided by ancient wisdom and modern ethics, we strive to make a positive difference in every life we touch."
          />

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {values.map((item, index) => (
              <div key={index} className="card-premium p-8 text-center">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary to-gold mx-auto mb-6 flex items-center justify-center">
                  <item.icon className="w-8 h-8 text-white" />
                </div>
                <h3 className="font-heading font-semibold text-xl text-foreground mb-4">{item.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Awards */}
      <section className="section-padding bg-gradient-to-br from-secondary via-royal to-royal-light">
        <div className="container-custom">
          <SectionHeader
            badge="Recognition"
            title="Awards & Achievements"
            subtitle="Our work has been recognized at national and international levels"
            light
          />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-8 border border-white/10 text-center">
              <div className="w-20 h-20 rounded-full bg-gold/20 mx-auto mb-6 flex items-center justify-center">
                <Award className="w-10 h-10 text-gold" />
              </div>
              <h3 className="font-heading font-bold text-2xl text-white mb-2">Asia Book Record</h3>
              <p className="text-white/70">Recognized for exceptional contribution to the field of astrology and Vastuvid in Asia.</p>
            </div>

            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-8 border border-white/10 text-center">
              <div className="w-20 h-20 rounded-full bg-primary/20 mx-auto mb-6 flex items-center justify-center">
                <Star className="w-10 h-10 text-primary" fill="currentColor" />
              </div>
              <h3 className="font-heading font-bold text-2xl text-white mb-2">India Book Record</h3>
              <p className="text-white/70">Honored for outstanding achievements in spreading Vedic knowledge across India.</p>
            </div>
          </div>
        </div>
      </section>

      <Footer />
      <WhatsAppButton variant="floating" />
    </div>
  );
};

export default About;
